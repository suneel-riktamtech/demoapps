/*global define */
define(['angular', 'sample-module'], function(angular, sampleModule) {
    'use strict';
    /* Services */
    sampleModule.value('version', '0.1');
    return sampleModule;
});
