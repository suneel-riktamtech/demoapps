define(['controllers/main', 'directives/main', 'filters/main', 'services/main'], function() {

});
