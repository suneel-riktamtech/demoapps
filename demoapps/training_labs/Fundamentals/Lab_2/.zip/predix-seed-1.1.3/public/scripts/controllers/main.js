define(['./dashboard', './data-control'], function() {

});
