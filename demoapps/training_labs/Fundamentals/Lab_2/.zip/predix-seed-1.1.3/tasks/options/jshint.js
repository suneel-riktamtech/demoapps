module.exports = {
    options: {
        jshintrc: '.jshintrc'
    },
    src: [
        'public/scripts/**/*.js'
    ],
    test: [
        'test/e2e/**/*.js',
        'test/spec/**/*.js'
    ]
}
