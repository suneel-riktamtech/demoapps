module.exports = {
    runner: {
        configFile: 'karma.conf.js',
        singleRun: true
    }
};
