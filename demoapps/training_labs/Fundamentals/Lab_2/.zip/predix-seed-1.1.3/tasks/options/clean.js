module.exports = {
    build: ['dist/www'],
    test: ['test-target/']
};
